#ifndef CODEGEN_H
#define CODEGEN_H

// Code generation phase functions

void CodeGen(AST *a,codeglobal &cg);

#endif

